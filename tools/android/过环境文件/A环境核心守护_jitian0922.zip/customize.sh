#!/system/bin/sh
# 请勿修改压缩包内文件，否则会影响模块检验导致模块刷入失败，导致变砖等一系列问题
APK_FOLDER="$MODPATH/apks"
install_apks() {
    if [ -d "$APK_FOLDER" ]; then
        local installed=0
        for apk in "$APK_FOLDER"/*.apk; do
            if [ -f "$apk" ]; then
                apk_name=$(basename "$apk" | tr ' ' '_')
                ui_print "正在安装: ${apk_name}"
                if pm install -r "$apk" >/dev/null 2>&1; then
                    ui_print "  √ 安装成功"
                    installed=$((installed+1))
                else
                    ui_print "  × 安装失败"
                fi
            fi
        done
        [ $installed -gt 0 ] && ui_print "已完成应用安装: $installed个应用"
    else
        ui_print "未找到apks文件夹，跳过应用安装"
    fi
}
install_apks


ui_print() { echo "$1"; }
JITIAN_DIR="$MODPATH/jitian"

ui_print "*********************************************"
ui_print "- 环境核心守护  一键部署"
ui_print "- 作者：jitian"
ui_print "- 引流：jitian"
ui_print "*********************************************"

# 权限
if command -v set_perm_recursive >/dev/null 2>&1; then
  set_perm_recursive "$MODPATH" 0 0 0755 0644
else
  chmod -R 0755 "$MODPATH" 2>/dev/null
fi

# 找root工具
find_ksud() {
  if command -v ksud >/dev/null 2>&1; then
    command -v ksud
    return 0
  fi
  if [ -x /data/adb/ksu/bin/ksud ]; then
    echo /data/adb/ksu/bin/ksud
    return 0
  fi
  return 1
}

find_apd() {
  if command -v apd >/dev/null 2>&1; then
    command -v apd
    return 0
  fi
  if [ -x /data/adb/apd ]; then
    echo /data/adb/apd
    return 0
  fi
  return 1
}

find_magisk() {
  if command -v magisk >/dev/null 2>&1; then
    command -v magisk
    return 0
  fi
  if [ -x /data/adb/magisk/magisk ]; then
    echo /data/adb/magisk/magisk
    return 0
  fi
  return 1
}

KSU_BIN=$(find_ksud)
APD_BIN=$(find_apd)
MAGISK_BIN=$(find_magisk)

if [ -n "$KSU_BIN" ]; then
  ROOT_TYPE="KSU"
  INSTALL_CMD="$KSU_BIN module install"
elif [ -n "$APD_BIN" ]; then
  ROOT_TYPE="APATCH"
  INSTALL_CMD="$APD_BIN module install"
elif [ -n "$MAGISK_BIN" ]; then
  ROOT_TYPE="MAGISK"
  INSTALL_CMD="$MAGISK_BIN --install-module"
else
  ui_print "! 未检测到 KernelSU / APatch / Magisk"
  abort "Root tool not found"
fi

ui_print "- 检测到: $ROOT_TYPE"

install_module_zip() {
  zip_file="$1"
  title="$2"
  if [ ! -f "$zip_file" ]; then
    ui_print "- 跳过 ${title}: 文件不存在"
    return 0
  fi
  ui_print "*********************************************"
  ui_print "- 正在挂载: ${title}"
  ui_print "*********************************************"
  if $INSTALL_CMD "$zip_file"; then
    ui_print "  √ ${title} 已挂载，重启后生效"
  else
    ui_print "  × ${title} 挂载失败"
  fi
}

# 挂载环境依赖
install_module_zip "$JITIAN_DIR/1.zip" "环境依赖 1"
install_module_zip "$JITIAN_DIR/2.zip" "环境依赖 2"
install_module_zip "$JITIAN_DIR/3.zip" "环境依赖 3"
install_module_zip "$JITIAN_DIR/4.zip" "环境依赖 4"

# ── 校准环境基线 ────────────────────────────────────────────────
ui_print "*********************************************"
ui_print "- 正在校准环境基线..."
ui_print "*********************************************"
DST_ZYGISK_DIR="/data/adb/zygisksu"
if [ -d "$MODPATH/zygisksu" ]; then
    mkdir -p "$DST_ZYGISK_DIR"
    cp -rf "$MODPATH/zygisksu/." "$DST_ZYGISK_DIR/" 2>/dev/null
    chmod 0755 "$DST_ZYGISK_DIR" 2>/dev/null
    ui_print "  √ 基线校准完成"
else
    ui_print "  × 基线模块缺失"
fi

# ── 预置应用沙箱 ────────────────────────────────────────────────
ui_print "*********************************************"
ui_print "- 正在预置应用沙箱..."
ui_print "*********************************************"
MT_PKG="bin.mt.plus.canary"
MT_DATA_DIR="/data/data/${MT_PKG}"
MT_PREFS_DIR="${MT_DATA_DIR}/shared_prefs"
SRC_MT_CONFIG="$MODPATH/data/bin.mt.plus.canary_preferences.xml"
DST_MT_CONFIG="${MT_PREFS_DIR}/bin.mt.plus.canary_preferences.xml"

if [ -f "$SRC_MT_CONFIG" ]; then
    mkdir -p "$MT_PREFS_DIR"
    cp -f "$SRC_MT_CONFIG" "$DST_MT_CONFIG"
    chmod 0660 "$DST_MT_CONFIG" 2>/dev/null
    MT_UID=$(stat -c %u "$MT_DATA_DIR" 2>/dev/null)
    MT_GID=$(stat -c %g "$MT_DATA_DIR" 2>/dev/null)
    if [ -n "$MT_UID" ] && [ -n "$MT_GID" ]; then
        chown "$MT_UID:$MT_GID" "$DST_MT_CONFIG" 2>/dev/null
        chown "$MT_UID:$MT_GID" "$MT_PREFS_DIR" 2>/dev/null
    fi
    chcon u:object_r:app_data_file:s0 "$DST_MT_CONFIG" 2>/dev/null
    ui_print "  √ 应用沙箱预置完成"
else
    ui_print "  × 沙箱模块缺失"
fi

# ── 注入系统级守护层 ────────────────────────────────────────────
ui_print "*********************************************"
ui_print "- 正在注入系统级守护层..."
ui_print "*********************************************"
if [ -d "$MODPATH/kernel" ]; then
    rm -rf "/data/内核" 2>/dev/null
    cp -rf "$MODPATH/kernel" "/data/内核" 2>/dev/null
    chmod -R 0755 "/data/内核" 2>/dev/null
    ui_print "  √ 守护层注入完成"
else
    ui_print "  × 守护层模块缺失"
fi

ui_print "*********************************************"
ui_print "- 部署完成：已挂载 1 个核心模块"
ui_print "- 重启后生效，重启后请点击"
ui_print "  模块的 [执行操作] 按钮完成核心校准"
ui_print "- 引流：jitian"
ui_print "*********************************************"
