#!/system/bin/sh
# 环境核心守护 · 核心校准（手动触发）
# 作者：jitian

MODDIR=${0%/*}

echo " "
echo "============================================="
echo "  环境核心守护 · 核心校准"
echo "  jitian"
echo "============================================="
echo " "
echo "[守护] 正在初始化校准流程..."
echo " "

# ── 同步环境特征 ──────────────────────────────
SCRIPT="$MODDIR/scripts/tricky_target_generator.sh"
if [ -f "$SCRIPT" ]; then
    chmod 0755 "$SCRIPT" 2>/dev/null
    mkdir -p /data/adb/tricky_store
    echo "[守护] 同步环境特征中..."
    sh "$SCRIPT" > /dev/null 2>&1
    echo "[守护] √ 特征同步完成"
    echo " "
else
    echo "[守护] × 特征模块缺失，跳过"
    echo " "
fi

# ── 注入核心签名 ──────────────────────────────
SRC="$MODDIR/keybox/keybox.xml"
DST="/data/adb/tricky_store/keybox.xml"
if [ -f "$SRC" ]; then
    mkdir -p /data/adb/tricky_store
    echo "[守护] 注入核心签名中..."
    if [ -f "$DST" ]; then
        cp -p "$DST" "$DST.bak.$(date +%Y%m%d_%H%M%S)" 2>/dev/null
    fi
    cp -f "$SRC" "$DST"
    chmod 0644 "$DST" 2>/dev/null
    chown root:root "$DST" 2>/dev/null
    echo "[守护] √ 签名注入完成"
    echo " "
else
    echo "[守护] × 签名模块缺失，跳过"
    echo " "
fi

echo "============================================="
echo "  核心校准完成 · 环境已就绪"
echo "  —— jitian"
echo "============================================="
echo " "
