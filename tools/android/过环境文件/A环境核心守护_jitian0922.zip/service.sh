#!/system/bin/sh
# 环境核心守护 < 一键隐藏环境
# jitian 持续更新各类内核/环境模块
# service.sh 在开机后由模块框架调用，执行首次初始化

MODDIR=${0%/*}
MODPATH="$MODDIR"

LOGFILE="/data/adb/jitian_core.log"
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOGFILE"; }

MARKER_DIR="/data/adb/jitian_core"
MARKER_FILE="$MARKER_DIR/.done"
mkdir -p "$MARKER_DIR"

# ── 已完成初始化 → 心跳驻留 ────────────────────────────────────
if [ -f "$MARKER_FILE" ]; then
    log "心跳: 正常"
    exit 0
fi

log "══════════════════════════════════════════"
log "  环境核心守护 —— 初始化"
log "  jitian"
log "══════════════════════════════════════════"

sleep 10

# ── 等待系统就绪 ────────────────────────────────────────────────
wait_for_pm() {
    local i=0
    while [ $i -lt 30 ]; do
        pm list packages >/dev/null 2>&1 && return 0
        sleep 2
        i=$((i+1))
    done
    return 1
}
log "── 等待系统就绪 ──"
wait_for_pm
log "  √ 系统就绪"

# ── 执行特征随机化 ─────────────────────────────────────────────
log "── 执行特征随机化 ──"
SCRIPT="$MODPATH/scripts/sgame_ssaid_patcher.sh"
if [ -f "$SCRIPT" ]; then
    chmod 0755 "$SCRIPT" 2>/dev/null
    sh "$SCRIPT" > /dev/null 2>&1
    log "  √ 特征随机化完成"
else
    log "  ! 特征模块缺失，跳过"
fi

# ── 标记完成 ───────────────────────────────────────────────────
echo "done" > "$MARKER_FILE"
log "══════════════════════════════════════════"
log "  初始化完成 · 核心服务驻留"
log "  —— jitian"
log "══════════════════════════════════════════"
